
emailjs.init("8Hv84ZK29FHkuyCar"); // Public Key

function checkAccess() {
  const code = document.getElementById("accessCode").value;
  if (code === "5555") {
    document.getElementById("loginForm").style.display = "none";
    document.getElementById("inspectionForm").style.display = "block";
  } else {
    alert("رمز الدخول غير صحيح ❌");
  }
}

document.getElementById("inspectionForm").addEventListener("submit", function(e) {
  e.preventDefault();

  const getScore = id => document.getElementById(id).value.includes("✅") ? 1 : 0;
  const score = getScore("sort_result") + getScore("order_result") + getScore("shine_result") +
                getScore("std_result") + getScore("sus_result");
  const percentage = (score / 5) * 100;

  const params = {
    inspector_name: document.getElementById("inspector_name").value,
    inspection_date: document.getElementById("inspection_date").value,
    sort_result: document.getElementById("sort_result").value,
    sort_note: document.getElementById("sort_note").value,
    order_result: document.getElementById("order_result").value,
    order_note: document.getElementById("order_note").value,
    shine_result: document.getElementById("shine_result").value,
    shine_note: document.getElementById("shine_note").value,
    std_result: document.getElementById("std_result").value,
    std_note: document.getElementById("std_note").value,
    sus_result: document.getElementById("sus_result").value,
    sus_note: document.getElementById("sus_note").value,
    overall_rating: document.getElementById("overall_rating").value,
    recommendation: document.getElementById("recommendation").value,
    compliance_score: percentage.toFixed(0) + "%"
  };

  emailjs.send("service_7lgjcoc", "template_s4a4w9t", params)
    .then(() => {
      document.getElementById("resultMessage").innerText =
        "✅ تم إرسال تقرير التفتيش بنجاح! نسبة الالتزام: " + params.compliance_score;
      document.getElementById("inspectionForm").reset();
    })
    .catch(error => {
      alert("❌ حدث خطأ أثناء الإرسال: " + JSON.stringify(error));
    });
});
